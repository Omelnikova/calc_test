For running test scenarios need to run MainRunner.java

In case of running separate scenarios:
- in *.feature file need to add tag (e.g. @dev) above to each particular scenario that will be tested
- in MainRunner.java - change 'tags = {"@test"}' -> 'tags = {"@dev"}'
- run MainRunner.java
