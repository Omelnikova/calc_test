package resources.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)

@CucumberOptions(
        features = {"src/test/java/resources/features/"},
        glue = {"steps"},
        monochrome = true,
        tags = {"@test"},
        format = {"pretty", "json:target/cucumber.json", //"com.cucumber.listener.ExtentCucumberFormatter:output/report.html"//
        }
)
public class MainRunner extends AbstractTestNGCucumberTests {

}

