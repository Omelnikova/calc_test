package steps;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class CalculatorPageSteps {
    WebDriver driver;

    @Before()
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "./chromedriver");
        this.driver = new ChromeDriver();
        this.driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
    }

    @After()
    public void tearDown() {
        this.driver.manage().deleteAllCookies();
        this.driver.close();
        this.driver.quit();
    }

    @Given("^the \"([^\"]*)\" page is opened$")
    public void thePageIsOpened(String url) {
        driver.get(url);
    }

    @And("^page is visible with \"([^\"]*)\" element$")
    public void pageIsVisibleWithElement(String element) {
        driver.findElement(By.cssSelector(element)).isDisplayed();
    }
    @When("^I click \"([^\"]*)\"$")
    public void iClick(String link) throws Throwable {
        driver.findElement(By.linkText( link )).click();
    }

    @Then("^I land on \"([^\"]*)\" page$")
    public void iLandOnPage(String targetUrl) throws Throwable {
        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl, targetUrl);
    }

    @When("^I type \"([^\"]*)\" in Percentage field on Percentage of a number form$")
    public void iTypeInPercentageFieldOnPercentageOfANumberForm(String percent) {
        List<WebElement> inputFirstFields = driver.findElements(By.cssSelector("form#f1 fieldset.values input"));
        inputFirstFields.get(0).sendKeys(percent);
    }

    @And("^I type \"([^\"]*)\" in Number field on Percentage of a number form$")
    public void iTypeNumberInNumberFieldOnPercentageOfANumberForm(String number) {
        List<WebElement> inputFierstFields = driver.findElements(By.cssSelector("form#f1 fieldset.values input"));
        inputFierstFields.get(1).sendKeys(number);
    }

    @And("^I click Calculate on Percentage of a number form$")
    public void iClickCalculateOnPercentageOfANumberForm() {
        driver.findElements(By.cssSelector("form#f1 fieldset.results input")).get(0).click();
    }

    @Then("^I see \"([^\"]*)\" as result on Percentage of a number form$")
    public void iSeeResultAsResultOnPercentageOfANumberForm(String expResult) {

        String actualResult = driver.findElements(By.cssSelector("form#f1 fieldset.results input")).get(1).getAttribute("value");
        Assert.assertEquals(expResult, actualResult);
    }

    @When("^I type \"([^\"]*)\" in first Number field on Percent of a number is another number form$")
    public void iTypeInFirstNumberFieldOnPercentOfANumberIsAnotherNumberForm(String number1) {
        driver.findElements(By.cssSelector("form#f2 fieldset.values input")).get(0).sendKeys(number1);
    }

    @And("^I type \"([^\"]*)\" in second Number field on Percent of a number is another number form$")
    public void iTypeInSecondNumberFieldOnPercentOfANumberIsAnotherNumberForm(String number2) {
        driver.findElements(By.cssSelector("form#f2 fieldset.values input")).get(1).sendKeys(number2);
    }

    @When("^I click Calculate on Percent of a number is another number form$")
    public void i_click_Calculate_on_Percent_of_a_number_is_another_number_form() {
        driver.findElements(By.cssSelector("form#f2 fieldset.results input")).get(0).click();
    }

    @Then("^I see \"([^\"]*)\" as result on Percent of a number is another number form$")
    public void i_see_as_result_on_Percent_of_a_number_is_another_number_form(String expectedResult) {
        String actualResult = driver.findElements(By.cssSelector("form#f2 fieldset.results input")).get(1).getAttribute("value");
        Assert.assertEquals(expectedResult, actualResult);
    }

    @When("^I type \"([^\"]*)\" in first Number field on Percentage increase/decrease from$")
    public void iTypeInFirstNumberFieldOnPercentageIncreaseDecreaseFrom(String number) {
        driver.findElements(By.cssSelector("form#f3 fieldset.values input")).get(0).sendKeys(number);
    }

    @And("^I type \"([^\"]*)\" in second Number field on Percentage increase/decrease from$")
    public void iTypeInSecondNumberFieldOnPercentageIncreaseDecreaseFrom(String number) {
        driver.findElements(By.cssSelector("form#f3 fieldset.values input")).get(1).sendKeys(number);
    }

    @And("^I click Calculate on Percentage increase/decrease from$")
    public void iClickCalculateOnPercentageIncreaseDecreaseFrom() {
        driver.findElements(By.cssSelector("form#f3 fieldset.results input")).get(0).click();
    }

    @Then("^I see \"([^\"]*)\" as result on Percentage increase/decrease from$")
    public void iSeeAsResultOnPercentageIncreaseDecreaseFrom(String expectedResult) {
        String actualResult = driver.findElements(By.cssSelector("form#f3 fieldset.results input")).get(1).getAttribute("value");
        Assert.assertEquals(expectedResult, actualResult);
    }

    @Then("^I see input fields are higlighted on Percentage of a number form$")
    public void iSeeInputFieldsAreHiglightedOnPercentageOfANumberForm() {
        String actualCss = driver.findElements(By.cssSelector("form#f1 fieldset.values input")).get(0).getAttribute("style");
        Assert.assertEquals(actualCss, "background: rgb(255, 238, 238);");
    }

    @Then("^I see input fields are higlighted on Percent of a number is another number form$")
    public void iSeeInputFieldsAreHiglightedOnPercentOfANumberIsAnotherNumberForm() {
        String actualCss = driver.findElements(By.cssSelector("form#f2 fieldset.values input")).get(0).getAttribute("style");
        Assert.assertEquals(actualCss, "background: rgb(255, 238, 238);");
    }

    @Then("^I see input fields are higlighted on Percentage increase/decrease from$")
    public void iSeeInputFieldsAreHiglightedOnPercentageIncreaseDecreaseFrom() {
        String actualCss = driver.findElements(By.cssSelector("form#f3 fieldset.values input")).get(0).getAttribute("style");
        Assert.assertEquals(actualCss, "background: rgb(255, 238, 238);");
    }

    @Then("^I see two blocks with google ads$")
    public void iSeeTwoBlocksWithGoogleAds() {
        List<WebElement> advBlocks = driver.findElements(By.cssSelector("ins.adsbygoogle"));
        advBlocks.get(0).isDisplayed();
        advBlocks.get(1).isDisplayed();
    }
}
