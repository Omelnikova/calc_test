//package steps;
//
//import cucumber.api.java.After;
//import cucumber.api.java.Before;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import java.util.concurrent.TimeUnit;
//
//public class BasicSteps {
//    WebDriver driver;
//
//    @Before()
//    public void setUp() {
//        System.setProperty("webdriver.chrome.driver", "./chromedriver");
//        this.driver = new ChromeDriver();
//        this.driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
//    }
//
//    @After()
//    public void tearDown() {
//        this.driver.manage().deleteAllCookies();
//        this.driver.close();
//        this.driver.quit();
//    }
//
//
//}
