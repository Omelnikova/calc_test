//package pageobjects;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//
//import java.util.List;
//
//public class FirstForm {
//
//    private WebDriver driver;
//
//    public FirstForm (WebDriver driver) {
//        this.driver = driver;
//    }
//
//    @FindBy(css = "form#f1 fieldset.values input")
//    private List<WebElement> formOneInputs;
//
//    public WebElement getFirstInputFormOne() {
//        return formOneInputs.get(0);
//    }
//}
